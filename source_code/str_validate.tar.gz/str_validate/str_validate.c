/*
 * str_validate
 *
 * Functions to validate input string as successfully castable to some
 * data type.
 * Joe Conway <mail@joeconway.com>
 *
 * Copyright 2003 by Joseph E. Conway
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without a written agreement
 * is hereby granted, provided that the above copyright notice and this
 * paragraph and the following two paragraphs appear in all copies.
 *
 * IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE AUTHOR OR DISTRIBUTORS HAVE BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS AND DISTRIBUTORS SPECIFICALLY DISCLAIM ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE AUTHOR AND DISTRIBUTORS HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 */
#include "postgres.h"

#include "fmgr.h"
#include "catalog/pg_type.h"
#include "utils/builtins.h"
#include "utils/date.h"
#include "utils/nabstime.h"
#include "utils/timestamp.h"

#define GET_STR(textp) DatumGetCString(DirectFunctionCall1(textout, PointerGetDatum(textp)))


/*
 * str_validate - return true if the provided text string can be cast without
 * error into the requested data type.
 */
extern Datum str_validate(PG_FUNCTION_ARGS);
PG_FUNCTION_INFO_V1(str_validate);

Datum
str_validate(PG_FUNCTION_ARGS)
{
	char   *str = GET_STR(PG_GETARG_TEXT_P(0));
	Oid		typeid = PG_GETARG_OID(1);

	switch (typeid)
	{
		case DATEOID:
			{
				fsec_t		fsec;
				struct tm	tt,
						   *tm = &tt;
				int			tzp;
				int			dtype;
				int			nf;
				char	   *field[MAXDATEFIELDS];
				int			ftype[MAXDATEFIELDS];
				char		lowstr[MAXDATELEN + 1];

				if (strlen(str) >= sizeof(lowstr))
					PG_RETURN_BOOL(false);

				if ((ParseDateTime(str, lowstr, field, ftype, MAXDATEFIELDS, &nf) != 0)
				 || (DecodeDateTime(field, ftype, nf, &dtype, tm, &fsec, &tzp) != 0))
					PG_RETURN_BOOL(false);

				switch (dtype)
				{
					case DTK_DATE:
					case DTK_EPOCH:
						break;

					case DTK_CURRENT:
						PG_RETURN_BOOL(false);
						break;

					default:
						PG_RETURN_BOOL(false);
				}

				/* must be OK */
				PG_RETURN_BOOL(true);
			}
			break;

		case TIMESTAMPOID:
			{
				Timestamp	result;
				fsec_t		fsec;
				struct tm	tt,
						   *tm = &tt;
				int			tz;
				int			dtype;
				int			nf;
				char	   *field[MAXDATEFIELDS];
				int			ftype[MAXDATEFIELDS];
				char		lowstr[MAXDATELEN + MAXDATEFIELDS];

				if (strlen(str) >= sizeof(lowstr))
					PG_RETURN_BOOL(false);

				if ((ParseDateTime(str, lowstr, field, ftype, MAXDATEFIELDS, &nf) != 0)
				  || (DecodeDateTime(field, ftype, nf, &dtype, tm, &fsec, &tz) != 0))
					PG_RETURN_BOOL(false);

				switch (dtype)
				{
					case DTK_EPOCH:
					case DTK_LATE:
					case DTK_EARLY:
						break;

					case DTK_DATE:
						if (tm2timestamp(tm, fsec, NULL, &result) != 0)
							PG_RETURN_BOOL(false);
						break;

					case DTK_INVALID:
						PG_RETURN_BOOL(false);
						break;

					default:
						PG_RETURN_BOOL(false);
				}

				/* must be OK */
				PG_RETURN_BOOL(true);
			}
			break;

		case INTERVALOID:
			{
				Interval   *result;
				fsec_t		fsec;
				struct tm	tt,
						   *tm = &tt;
				int			dtype;
				int			nf;
				char	   *field[MAXDATEFIELDS];
				int			ftype[MAXDATEFIELDS];
				char		lowstr[MAXDATELEN + MAXDATEFIELDS];

				tm->tm_year = 0;
				tm->tm_mon = 0;
				tm->tm_mday = 0;
				tm->tm_hour = 0;
				tm->tm_min = 0;
				tm->tm_sec = 0;
				fsec = 0;

				if (strlen(str) >= sizeof(lowstr))
					PG_RETURN_BOOL(false);

				if ((ParseDateTime(str, lowstr, field, ftype, MAXDATEFIELDS, &nf) != 0)
					|| (DecodeInterval(field, ftype, nf, &dtype, tm, &fsec) != 0))
					PG_RETURN_BOOL(false);

				result = (Interval *) palloc(sizeof(Interval));

				switch (dtype)
				{
					case DTK_DELTA:
						if (tm2interval(tm, fsec, result) != 0)
							PG_RETURN_BOOL(false);
						break;

					case DTK_INVALID:
						PG_RETURN_BOOL(false);
						break;

					default:
						PG_RETURN_BOOL(false);
				}

				/* must be OK */
				PG_RETURN_BOOL(true);
			}
			break;

		default:
			elog(ERROR, "Unsupported data type '%s'", format_type_be(typeid));
	}

	/* keep the compiler quiet */
	PG_RETURN_BOOL(true);
}

