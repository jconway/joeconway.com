-- Adjust this setting to control where the objects get created.
SET search_path = public;

CREATE OR REPLACE FUNCTION sess_setvar(text, text)
RETURNS text
AS '$libdir/sessfunc','sess_setvar'
LANGUAGE 'C' IMMUTABLE STRICT;

CREATE OR REPLACE FUNCTION sess_getvar(text)
RETURNS text
AS '$libdir/sessfunc','sess_getvar'
LANGUAGE 'C' STABLE STRICT;

CREATE OR REPLACE FUNCTION sess_rmvar(text)
RETURNS text
AS '$libdir/sessfunc','sess_rmvar'
LANGUAGE 'C' IMMUTABLE STRICT;
