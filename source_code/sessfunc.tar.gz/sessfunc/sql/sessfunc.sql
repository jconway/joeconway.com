--
-- first, define the functions.  Turn off echoing so that expected file
-- does not depend on contents of sessfunc.sql.
--
\set ECHO none
\i sessfunc.sql
\set ECHO all

CREATE TABLE user_data
(
  id int       primary key,
  luser   text unique,
  name    text,
  city    text,
  country text
);

INSERT INTO user_data
 VALUES(1, 'joe', 'Joe', 'San Diego', 'USA');
INSERT INTO user_data
 VALUES(2, 'bob', 'Bob', 'Portland', 'USA');

SELECT sess_setvar('luser','joe');
SELECT * FROM user_data
 WHERE luser = sess_getvar('luser');
SELECT sess_rmvar('luser');
SELECT * FROM user_data
 WHERE luser = sess_getvar('luser');
CREATE OR REPLACE VIEW USER_DATA_VW AS
 SELECT * FROM user_data
  WHERE luser = sess_getvar('luser');
SELECT sess_setvar('luser','joe');
SELECT * FROM user_data_vw;
