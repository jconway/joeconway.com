/*
 * sessfunc
 *
 * Global session variables
 * Joe Conway <mail@joeconway.com>
 *
 * Copyright (c) 2004-2005, PostgreSQL Global Development Group
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without a written agreement
 * is hereby granted, provided that the above copyright notice and this
 * paragraph and the following two paragraphs appear in all copies.
 *
 * IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE AUTHOR OR DISTRIBUTORS HAVE BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHORS AND DISTRIBUTORS SPECIFICALLY DISCLAIM ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE AUTHOR AND DISTRIBUTORS HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 */

#include "postgres.h"

#include "fmgr.h"
#include "utils/builtins.h"
#include "utils/hsearch.h"
#include "utils/memutils.h"

/*
 * exported functions
 */
extern Datum sess_setvar(PG_FUNCTION_ARGS);
extern Datum sess_getvar(PG_FUNCTION_ARGS);
extern Datum sess_rmvar(PG_FUNCTION_ARGS);


/*
 * internal
 */
static char *getStrByName(const char *name);
static HTAB *createStrHash(void);
static void createNewStr(const char *name, char *str);
static void deleteStr(const char *name);

static HTAB *strHash = NULL;
typedef struct strHashEnt
{
	char		name[NAMEDATALEN];
	char	   *str;
}	strHashEnt;


/*
 * definitions
 */
#define NUMSTR 16
#define PG_CSTR_GET_TEXT(cstrp) DatumGetTextP(DirectFunctionCall1(textin, CStringGetDatum(cstrp)))
#define PG_TEXT_GET_CSTR(textp) DatumGetCString(DirectFunctionCall1(textout, PointerGetDatum(textp)))

/*
 * structure to cache lookup metadata
 */
typedef struct LookupState
{
	char	   *name;
	char	   *str;
} LookupState;

/*
 * Create a named persistent string
 */
PG_FUNCTION_INFO_V1(sess_setvar);
Datum
sess_setvar(PG_FUNCTION_ARGS)
{
	char	   *name = NULL;
	char	   *str = NULL;

	name = PG_TEXT_GET_CSTR(PG_GETARG_TEXT_P(0));
	str = PG_TEXT_GET_CSTR(PG_GETARG_TEXT_P(1));

	createNewStr(name, str);

	PG_RETURN_TEXT_P(PG_CSTR_GET_TEXT("OK"));
}

/*
 * Retrieve a named persistent string
 */
PG_FUNCTION_INFO_V1(sess_getvar);
Datum
sess_getvar(PG_FUNCTION_ARGS)
{
	char	   *name = NULL;
	char	   *str = NULL;
	LookupState *my_extra;
	
	name = PG_TEXT_GET_CSTR(PG_GETARG_TEXT_P(0));

	/*
	 * We arrange to look up info about the variable
	 * only once per series of calls, assuming the
	 * var name requested doesn't change underneath us.
	 */
	my_extra = (LookupState *) fcinfo->flinfo->fn_extra;
	if (my_extra == NULL)
	{
		fcinfo->flinfo->fn_extra = MemoryContextAlloc(fcinfo->flinfo->fn_mcxt,
												 sizeof(LookupState));
		my_extra = (LookupState *) fcinfo->flinfo->fn_extra;
		my_extra->name = NULL;
	}

	if (!my_extra->name || strcmp(my_extra->name, name) != 0)
	{
		MemoryContext	oldcontext;
		
		/* ensure the strings have sufficiently long lifespan */
		oldcontext = MemoryContextSwitchTo(fcinfo->flinfo->fn_mcxt);
		
		/* Get info about the variable */
		my_extra->str = getStrByName(name);
		if (!my_extra->str)
			ereport(WARNING, (errmsg("variable \"%s\" not set", name)));
		
		my_extra->name = pstrdup(name);
		
		/* restore callers memory context */
		MemoryContextSwitchTo(oldcontext);
	}
	str = my_extra->str;
	
	if (str)
		PG_RETURN_TEXT_P(PG_CSTR_GET_TEXT(str));
	else
		PG_RETURN_NULL();
}

/*
 * Delete a named persistent string
 */
PG_FUNCTION_INFO_V1(sess_rmvar);
Datum
sess_rmvar(PG_FUNCTION_ARGS)
{
	char	   *name = NULL;

	name = PG_TEXT_GET_CSTR(PG_GETARG_TEXT_P(0));

	deleteStr(name);

	PG_RETURN_TEXT_P(PG_CSTR_GET_TEXT("OK"));
}



/*****************************************************************
 * local functions
 */
static char *
getStrByName(const char *name)
{
	strHashEnt *hentry;
	char		key[NAMEDATALEN];

	if (!strHash)
		strHash = createStrHash();

	MemSet(key, 0, NAMEDATALEN);
	snprintf(key, NAMEDATALEN - 1, "%s", name);
	hentry = (strHashEnt *) hash_search(strHash, key, HASH_FIND, NULL);

	if (hentry)
		return (hentry->str);
		
	return (NULL);
}

static HTAB *
createStrHash(void)
{
	HASHCTL		ctl;
	HTAB	   *ptr;

	ctl.keysize = NAMEDATALEN;
	ctl.entrysize = sizeof(strHashEnt);

	ptr = hash_create("str hash", NUMSTR, &ctl, HASH_ELEM);

	if (!ptr)
		ereport(ERROR,
				(errcode(ERRCODE_OUT_OF_MEMORY),
				 errmsg("out of memory")));

	return (ptr);
}

static void
createNewStr(const char *name, char *str)
{
	strHashEnt *hentry;
	bool		found;
	char		key[NAMEDATALEN];

	if (!strHash)
		strHash = createStrHash();

	MemSet(key, 0, NAMEDATALEN);
	snprintf(key, NAMEDATALEN - 1, "%s", name);
	hentry = (strHashEnt *) hash_search(strHash, key, HASH_ENTER, &found);

	if (!hentry)
		ereport(ERROR,
				(errcode(ERRCODE_OUT_OF_MEMORY),
				 errmsg("out of memory")));

	if (found)
	{
		if (hentry->str)
			pfree(hentry->str);
	}
	else
		strncpy(hentry->name, name, NAMEDATALEN - 1);

	hentry->str = MemoryContextStrdup(TopMemoryContext, str);
}

static void
deleteStr(const char *name)
{
	strHashEnt *hentry;
	bool		found;
	char		key[NAMEDATALEN];

	if (!strHash)
		strHash = createStrHash();

	MemSet(key, 0, NAMEDATALEN);
	snprintf(key, NAMEDATALEN - 1, "%s", name);

	hentry = (strHashEnt *) hash_search(strHash, key, HASH_REMOVE, &found);

	if (!hentry)
		ereport(ERROR,
				(errcode(ERRCODE_UNDEFINED_OBJECT),
				 errmsg("undefined string name")));

	if (hentry->str)
		pfree(hentry->str);
}
