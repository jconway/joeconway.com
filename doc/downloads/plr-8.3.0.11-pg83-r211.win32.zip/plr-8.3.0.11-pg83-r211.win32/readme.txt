Set the R_HOME evironment variable to point to the R install folder (e.g., C:\Program Files\R\R-2.11.1)
Add the R_HOME bin folder to the Path environment folder: %PATH%;C:\Program Files\R\R-2.11.1\bin
Add the plr.dll file to C:\Program Files\PostgreSQL\8.3\lib
Optionally add the plr.sql file to C:\Program Files\PostgreSQL\8.3\share\contrib
