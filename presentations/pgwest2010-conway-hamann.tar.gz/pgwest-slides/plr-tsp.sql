/*
 * Example code from PgWest 2010
 *
 * Joe Conway <mail@joeconway.com>
 * Jeff Hamann <jeff.hamann@forestinformatics.com>
 * Copyright (c) 2010, Joe Conway, Jeff Hamann
 * ALL RIGHTS RESERVED;
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without a written agreement
 * is hereby granted, provided that the above copyright notice and this
 * paragraph and the following two paragraphs appear in all copies.
 *
 * IN NO EVENT SHALL THE AUTHOR OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE AUTHOR OR DISTRIBUTORS HAVE BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHOR AND DISTRIBUTORS SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE AUTHOR AND DISTRIBUTORS HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 */

CREATE TABLE stands
(
    id serial primary key,	-- A_{b}
    strata integer not null, -- A^{s}_{b}
    initage integer -- A^{a}_{b}
);

-- create a field named boundary, using SRID EPSG:4326 in 2 dimensions
-- and create an index
SELECT AddGeometryColumn('','stands','boundary','4326','MULTIPOLYGON',2);
CREATE INDEX "stands_boundary_gist" ON "stands" USING gist ("boundary" gist_geometry_ops);

-- and create a point that will represent a landing, using SRID EPSG:4326 in 2 dimensions
SELECT AddGeometryColumn('','stands','location','4326','POINT',2);
CREATE INDEX "stands_location_gist" ON "stands" USING gist ("location" gist_geometry_ops);

-- and add a comment
COMMENT ON TABLE stands IS 'a table that contains stand data for the forest';

-- ingest the data.
-- add data to the stands table using insert commands constructed by hand
INSERT INTO stands (id,strata,initage,boundary,location) VALUES
 (1,1,1,GeometryFromText('MULTIPOLYGON(((  59.250000 65.000000,  55.000000 65.000000,  55.000000 51.750000,  60.735294 53.470588,  62.875000 57.750000, 59.250000 65.000000 )))', 4326) ,GeometryFromText('POINT( 61.000000 59.000000 )', 4326 ))
,(2,2,1,GeometryFromText('MULTIPOLYGON(((  67.000000 65.000000,  59.250000 65.000000,  62.875000 57.750000,  67.000000 60.500000, 67.000000 65.000000 )))', 4326) ,GeometryFromText('POINT( 63.000000 60.000000 )', 4326 ))
,(3,3,1,GeometryFromText('MULTIPOLYGON(((  67.045455 52.681818,  60.735294 53.470588,  55.000000 51.750000,  55.000000 45.000000,  65.125000 45.000000, 67.045455 52.681818 )))', 4326) ,GeometryFromText('POINT( 64.000000 49.000000 )', 4326 ))
,(4,4,1,GeometryFromText('MULTIPOLYGON(((  71.500000 53.500000,  70.357143 53.785714,  67.045455 52.681818,  65.125000 45.000000,  71.500000 45.000000, 71.500000 53.500000 )))', 4326) ,GeometryFromText('POINT( 68.000000 48.000000 )', 4326 ))
,(5,5,1,GeometryFromText('MULTIPOLYGON(((  69.750000 65.000000,  67.000000 65.000000,  67.000000 60.500000,  70.357143 53.785714,  71.500000 53.500000,  74.928571 54.642857, 69.750000 65.000000 )))', 4326) ,GeometryFromText('POINT( 71.000000 60.000000 )', 4326 ))
,(6,6,1,GeometryFromText('MULTIPOLYGON(((  80.000000 65.000000,  69.750000 65.000000,  74.928571 54.642857,  80.000000 55.423077, 80.000000 65.000000 )))', 4326) ,GeometryFromText('POINT( 73.000000 61.000000 )', 4326 ))
,(7,7,1,GeometryFromText('MULTIPOLYGON(((  80.000000 55.423077,  74.928571 54.642857,  71.500000 53.500000,  71.500000 45.000000,  80.000000 45.000000, 80.000000 55.423077 )))', 4326) ,GeometryFromText('POINT( 75.000000 48.000000 )', 4326 ))
,(8,8,1,GeometryFromText('MULTIPOLYGON(((  67.000000 60.500000,  62.875000 57.750000,  60.735294 53.470588,  67.045455 52.681818,  70.357143 53.785714, 67.000000 60.500000 )))', 4326) ,GeometryFromText('POINT( 65.000000 57.000000 )', 4326 ))
;

-- then, create the function to update the forest boundary
-- drop an existing table, st_union the stands, report the time.
--------------------------------------------------------------------------------
-- this function creates a boundary for the forest
-- here, the boundary is the geometric union of the stand polygons
CREATE OR REPLACE FUNCTION update_forest_boundary() RETURNS interval AS $$
DECLARE
  beg_time timestamp;
  end_time timestamp;
BEGIN
  beg_time := timeofday();

  DROP TABLE IF EXISTS boundary CASCADE;
  CREATE TABLE boundary AS SELECT ST_Union(boundary) AS bdry FROM stands;
  ALTER TABLE boundary ADD COLUMN gid serial;
  ALTER TABLE boundary ADD CONSTRAINT gid_pkey PRIMARY KEY  (gid);

  end_time := timeofday();
  return(end_time - beg_time);
END;
$$ language 'plpgsql';

-- generate the boundary polygon
SELECT * FROM update_forest_boundary();

--------------------------------------------------------------------------------
-- next, create a view that can be used to generate the kml file
-- this area is reported in square degrees
-- reproject to oregon state plane blah, blah, blah 
-- srid epsg:2992
SELECT *, area(bdry), area(st_transform(bdry,2992)) FROM boundary;


-- this one is in square degrees and acres (reprojected in oregon state plane, feet)
-- and a bunch of other functions.
SELECT gid, 
       area(bdry) AS sqdeg, 
       area(st_transform(bdry,2992))/43560.0 AS acres,
       area(st_transform(bdry,2992))/43560.0/2.47 AS hectares,

       -- add another srid to demonstrate the influence of units on angles (area)
       
       st_summary(bdry),
       box2d(bdry)
FROM boundary;


--------------------------------------------------------------------------------
-- finally, generate a query to produce the Google Earth File
-- create view rpt_google_earth;
DROP VIEW IF EXISTS kml_stands;
CREATE OR REPLACE VIEW kml_stands AS SELECT 

    s1.id,
    'Stand #' || s1.id AS name,
    s1.strata AS strata,

    -- add the bounding box for gmt maps
    st_xmin( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) ) || '/' || 
    st_xmax( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) ) || '/' || 
    st_ymin( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) ) || '/' || 
    st_ymax( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) )  AS gmt_bbox,

    -- add the area, in both acres and hectares
    area(st_transform(s1.boundary,2992))/43560.0 AS acres,
    area(st_transform(s1.boundary,2992))/43560.0/2.47 AS hectares,
    st_summary(s1.boundary),

    -- add the url for the class.
    E'http://www.credativ.us/pg_w_spatial/' as class_site,
    E'http://www.credativ.us/news/2010/06/15/credativ-llc-and-forest-informatics-inc-announce-p/' as shameless_self_promotion,

    -- for ogr2ogr using kml to work well, this needs to be the last entry in the row.
    astext(st_transform(s1.boundary,4326))
FROM 
    stands as s1
ORDER BY 
    s1.id;

-- create a simple view to reduce the workload for the query that is used to generate the data.frame
-- that is fed into sqli2[sp,map]
CREATE VIEW RPT_STANDS AS
SELECT 
       *,
       ST_AsText(boundary) as wktgeom, -- this is the data 'type' that is needed by sqli2map()
       st_xmin( boundary) as minx, -- looks like the function also needs the bbox too.
       st_ymin( boundary) as miny,
       st_xmax( boundary) as maxx,
       st_ymax( boundary) as maxy
FROM
	stands
ORDER BY
      id;

-- in short you must begin with a table/view that looks like this (five appended columns)
-- to be able to use the SQLiteMap function sqli2map

-- create the extensions to create stored procedures using R.
-- Thanks to Joe Conway
-- \i /usr/local/pgsql/share/contrib/plr.sql 

-- create some simple function to generate the map plot
-- very simple function 
-- you'll need to move it out of data directory 
create or replace function print_tsp_map ( cid int ) returns text as
$$
	## load the SQLiteMap package to get the sqli2map function
	library( SQLiteMap )

      	## open the database, get the mill, and the prices.
       	stands <- pg.spi.exec( sprintf( "select * from rpt_stands;" ) )         

       	## stands is now a data.frame object that contains HEXEWKB columns
       	## it would be nice if the data.frame could be easily converted into an R spatial object
	## this is the objective of the smaller oscon project
       	stands.map <- sqli2map(geoms=stands, gcol='wktgeom')

	##################################################################
	## this is where we would show some very useful, creative stuff
	## with the spatial capabilites within R, all from within PostgreSQL
	##################################################################


       	## plot a/the map to /usr/local/pgsql/data
       	pdf( "tour2.pdf" )
       	plot( stands.map )
       	dev.off()

       	return( "hi mom" )

$$
language 'plr' strict;


select * from print_tsp_map( 0 );

-- define the table that will match the returning data.frame
DROP TABLE IF EXISTS events CASCADE;
CREATE TABLE events
(
  seqid int not null primary key, -- visit sequence #
  plotid int, -- original plot id
  bearing real, -- bearing to next waypoint
  distance real,  -- distance to next waypoint
  velocity real, -- velocity of travel, in nm/hr
  traveltime real, -- travel time to next event
  loitertime real, -- how long to hang out
  totaltraveldist real, -- cummulative distance
  totaltraveltime real -- cummulaative time
);

-- you can add geometry too
SELECT AddGeometryColumn('','events','location','4326','POINT',2);
CREATE INDEX "events_location_gist" ON "events" USING gist ("location" gist_geometry_ops);

CREATE TABLE plr_modules (
  modseq int4 primary key,
  modsrc text
);

INSERT INTO plr_modules
  VALUES (0, $$
  make.route <-function(tour, waypts, dist.matrix) {
    velocity <- 500.0
    starts <- tour[1:(length(tour))-1]
    stops <- tour[2:(length(tour))]
    dist.vect <- diag( as.matrix( dist.matrix )[starts,stops] )
    last.leg <- as.matrix( dist.matrix )[tour[length(tour)],tour[1]]
    dist.vect <- c(dist.vect, last.leg )
    delta.x <- diff( waypts[tour,]$x )
    delta.y <- diff( waypts[tour,]$y )
    bearings <- atan( delta.x/delta.y ) * 180 / pi
    bearings <- c(bearings,0)
    for( i in 1:(length(tour)-1) ) {
      if( delta.x[i] > 0.0 && delta.y[i] > 0.0 ) bearings[i] <- bearings[i]
      if( delta.x[i] > 0.0 && delta.y[i] < 0.0 ) bearings[i] <- 180.0 + bearings[i]
      if( delta.x[i] < 0.0 && delta.y[i] > 0.0 ) bearings[i] <- 360.0 + bearings[i]
      if( delta.x[i] < 0.0 && delta.y[i] < 0.0 ) bearings[i] <- 180 + bearings[i]
    }
    route <- data.frame(seq=1:length(tour), ptid=tour, bearing=bearings, dist.vect=dist.vect,
                        velocity=velocity, travel.time=dist.vect/velocity, loiter.time=0.5)
    route$total.travel.dist <- cumsum(route$dist.vect)
    route$total.travel.time <- cumsum(route$travel.time+route$loiter.time)
    route$location <- waypts[tour,]$location
    return(route)
  }$$
);

INSERT INTO plr_modules
  VALUES (1, $$
  make.map <-function(tour, waypts, mapname) {
    require(maps)

    jpeg(file=mapname, width = 480, height = 480, pointsize = 10, quality = 75)
    map('world2', xlim = c(20, 120), ylim=c(20,80) )
    map.axes()
    grid()
    arrows(waypts[tour[1:(length(tour)-1)],]$x, waypts[tour[1:(length(tour)-1)],]$y,
           waypts[tour[2:(length(tour))],]$x, waypts[tour[2:(length(tour))],]$y,
           angle=10, lwd=1, length=.15, col="red")

    points( waypts$x, waypts$y, pch=3, cex=2 )
    points( waypts$x, waypts$y, pch=20, cex=0.8 )

    text(  waypts$x+2, waypts$y+2, as.character( waypts$id  ), cex=0.8 )
    title( "TSP soln using PL/R" )
    dev.off()
  }$$
);
SELECT reload_plr_modules();

CREATE OR REPLACE FUNCTION solve_tsp(makemap bool, mapname text) RETURNS SETOF events AS
$$
  require(TSP)
  require(fields)

  sql.str <- "select id, st_x(location) as x, st_y(location) as y, location from stands;" 
  waypts <- pg.spi.exec(sql.str)

  dist.matrix <-  rdist.earth(waypts[,2:3], R=3949.0)
  rtsp <- TSP(dist.matrix)
  soln <- solve_TSP(rtsp)
  tour <- as.vector(soln)
  pg.thrownotice( paste("tour.dist=", attributes(soln)$tour_length))

  route <- make.route(tour, waypts, dist.matrix)
  if (makemap) {
    make.map(tour, waypts, mapname)
  }

  return(route)
$$
LANGUAGE 'plr' STRICT;



-- test the results
SELECT * FROM solve_tsp(true, 'tsp.jpg');


-- also check out the map
-- $ sudo cp /usr/local/pgsql/data/tour-with-map-from-plr.pdf .
-- $ sudo chmod 744 tour-with-map-from-plr.pdf
-- $ open tour-with-map-from-plr.pdf




