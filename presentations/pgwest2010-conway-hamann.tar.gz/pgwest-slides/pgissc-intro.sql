/*
 * Example code from PgWest 2010
 *
 * Joe Conway <mail@joeconway.com>
 * Jeff Hamann <jeff.hamann@forestinformatics.com>
 * Copyright (c) 2010, Joe Conway, Jeff Hamann
 * ALL RIGHTS RESERVED;
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without a written agreement
 * is hereby granted, provided that the above copyright notice and this
 * paragraph and the following two paragraphs appear in all copies.
 *
 * IN NO EVENT SHALL THE AUTHOR OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE AUTHOR OR DISTRIBUTORS HAVE BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHOR AND DISTRIBUTORS SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE AUTHOR AND DISTRIBUTORS HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 */

--	$Id: pgissc.sql 92 2010-10-07 15:23:43Z hamannj $	

-- this is the file that you can use to demonstrate the "postgis 10 slide, 20 minute" presentation.

-- this file performs the following tasks:
-- 1) creates the table defs for stands, roads, and streams
-- 2) insert data for stands, roads and streams in EPSG:4326
-- 3) creates a boundary from the stands using the st_union function
-- 4) creates an adjacency list from the stands that touch each other
-- 5) creates the view to report forest statistics
-- then using ogr2ogr, write a google earth file using the view.

-- step 0. create the database
-- $ createdb -h localhost -U postgres pgissc

-- $ psql -h localhost -U postgres pgissc
-- psql (8.4.4)
-- Type "help" for help.

-- pgissc=# 


-- Step 1.
-- first, create the plpgsql capabilites
--CREATE LANGUAGE plpgsql;

-- then, load postgis functions, spatial reference systems, and function comments
--\i /usr/local/pgsql/share/contrib/postgis-1.5/postgis.sql 
--\i /usr/local/pgsql/share/contrib/postgis-1.5/spatial_ref_sys.sql 

--
-- or better, do the following at the command line
--
/*
dropdb -h localhost -U postgres pgissc
createdb -h localhost -U postgres pgissc
createlang -h localhost -U postgres plpgsql pgissc
psql -h localhost -U postgres pgissc \
  < ${PGINSTROOT}/share/contrib/postgis-1.5/postgis.sql \
  > postgis.sql.out 2>&1
grep ERROR postgis.sql.out
psql -h localhost -U postgres pgissc \
  < ${PGINSTROOT}/share/contrib/postgis-1.5/spatial_ref_sys.sql \
  > spatial_ref_sys.sql.out 2>&1
grep ERROR spatial_ref_sys.sql.out
psql -h localhost -U postgres pgissc \
  < ${PGINSTROOT}/share/contrib/plr.sql \
  > plr.sql.out 2>&1
grep ERROR plr.sql.out
*/




--------------------------------------------------------------------------------- 
-- then, define your tables.
-- here, we create a table for the stand stands (polygons), roads (lines) and streams (lines)
CREATE TABLE stands
(
    id serial primary key,	-- A_{b}
    strata integer not null, -- A^{s}_{b}
    initage integer -- A^{a}_{b}
);

-- create a field named boundary, using SRID EPSG:4326 in 2 dimensions
-- and create an index
SELECT AddGeometryColumn('','stands','boundary','4326','MULTIPOLYGON',2);
CREATE INDEX "stands_boundary_gist" ON "stands" using gist ("boundary" gist_geometry_ops);

-- and create a point that will represent a landing, using SRID EPSG:4326 in 2 dimensions
SELECT AddGeometryColumn('','stands','location','4326','POINT',2);
CREATE INDEX "stands_location_gist" ON "stands" using gist ("location" gist_geometry_ops);

-- and add a comment
COMMENT ON TABLE stands IS 'a table that contains stand data for the forest';

-- ingest the data.
-- add data to the stands table using insert commands constructed by hand
INSERT INTO stands (id,strata,initage,boundary,location) VALUES
 (1,1,1,GeometryFromText('MULTIPOLYGON(((  59.250000 65.000000,  55.000000 65.000000,  55.000000 51.750000,  60.735294 53.470588,  62.875000 57.750000, 59.250000 65.000000 )))', 4326) ,GeometryFromText('POINT( 61.000000 59.000000 )', 4326 ))
,(2,2,1,GeometryFromText('MULTIPOLYGON(((  67.000000 65.000000,  59.250000 65.000000,  62.875000 57.750000,  67.000000 60.500000, 67.000000 65.000000 )))', 4326) ,GeometryFromText('POINT( 63.000000 60.000000 )', 4326 ))
,(3,3,1,GeometryFromText('MULTIPOLYGON(((  67.045455 52.681818,  60.735294 53.470588,  55.000000 51.750000,  55.000000 45.000000,  65.125000 45.000000, 67.045455 52.681818 )))', 4326) ,GeometryFromText('POINT( 64.000000 49.000000 )', 4326 ))
,(4,4,1,GeometryFromText('MULTIPOLYGON(((  71.500000 53.500000,  70.357143 53.785714,  67.045455 52.681818,  65.125000 45.000000,  71.500000 45.000000, 71.500000 53.500000 )))', 4326) ,GeometryFromText('POINT( 68.000000 48.000000 )', 4326 ))
,(5,5,1,GeometryFromText('MULTIPOLYGON(((  69.750000 65.000000,  67.000000 65.000000,  67.000000 60.500000,  70.357143 53.785714,  71.500000 53.500000,  74.928571 54.642857, 69.750000 65.000000 )))', 4326) ,GeometryFromText('POINT( 71.000000 60.000000 )', 4326 ))
,(6,6,1,GeometryFromText('MULTIPOLYGON(((  80.000000 65.000000,  69.750000 65.000000,  74.928571 54.642857,  80.000000 55.423077, 80.000000 65.000000 )))', 4326) ,GeometryFromText('POINT( 73.000000 61.000000 )', 4326 ))
,(7,7,1,GeometryFromText('MULTIPOLYGON(((  80.000000 55.423077,  74.928571 54.642857,  71.500000 53.500000,  71.500000 45.000000,  80.000000 45.000000, 80.000000 55.423077 )))', 4326) ,GeometryFromText('POINT( 75.000000 48.000000 )', 4326 ))
,(8,8,1,GeometryFromText('MULTIPOLYGON(((  67.000000 60.500000,  62.875000 57.750000,  60.735294 53.470588,  67.045455 52.681818,  70.357143 53.785714, 67.000000 60.500000 )))', 4326) ,GeometryFromText('POINT( 65.000000 57.000000 )', 4326 ))
;

-- pgissc=# \d+
--                                                 List of relations
--  Schema |       Name        |   Type   |  Owner   |    Size    |                   Description                   
-- --------+-------------------+----------+----------+------------+-------------------------------------------------
--  public | geography_columns | view     | postgres | 0 bytes    | 
--  public | geometry_columns  | table    | postgres | 8192 bytes | 
--  public | spatial_ref_sys   | table    | postgres | 2944 kB    | 
--  public | stands            | table    | postgres | 8192 bytes | a table that contains stand data for the forest
--  public | stands_id_seq     | sequence | postgres | 8192 bytes | 
-- (5 rows)

-- pgissc=# 

-- the results are displayed in WKB or EWKB -- I can't recall which

-- here's the table definition with the geometry fields
-- pgissc=# \d+ stands
--                                        Table "public.stands"
--   Column  |   Type   |                      Modifiers                      | Storage | Description 
-- ----------+----------+-----------------------------------------------------+---------+-------------
--  id       | integer  | not null default nextval('stands_id_seq'::regclass) | plain   | 
--  strata   | integer  | not null                                            | plain   | 
--  initage  | integer  |                                                     | plain   | 
--  boundary | geometry |                                                     | main    | 
--  location | geometry |                                                     | main    | 
-- Indexes:
--     "stands_pkey" PRIMARY KEY, btree (id)
--     "stands_boundary_gist" gist (boundary)
--     "stands_location_gist" gist (location)
-- Check constraints:
--     "enforce_dims_boundary" CHECK (st_ndims(boundary) = 2)
--     "enforce_dims_location" CHECK (st_ndims(location) = 2)
--     "enforce_geotype_boundary" CHECK (geometrytype(boundary) = 'MULTIPOLYGON'::text OR boundary IS NULL)
--     "enforce_geotype_location" CHECK (geometrytype(location) = 'POINT'::text OR location IS NULL)
--     "enforce_srid_boundary" CHECK (st_srid(boundary) = 4326)
--     "enforce_srid_location" CHECK (st_srid(location) = 4326)
-- Has OIDs: no

-- pgissc=# 



-- add the remaining data (or read in using ogr?)
--------------------------------------------------------------------------------- 
-- insert some roads into the forest 
-- these were also generated externally (in R)
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (1,1,2,1, GeometryFromText('LINESTRING(61.000000 59.000000, 63.000000 60.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (2,1,3,1, GeometryFromText('LINESTRING(61.000000 59.000000, 64.000000 49.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (3,3,4,1, GeometryFromText('LINESTRING(64.000000 49.000000, 68.000000 48.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (4,2,5,1, GeometryFromText('LINESTRING(63.000000 60.000000, 71.000000 60.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (5,4,5,1, GeometryFromText('LINESTRING(68.000000 48.000000, 71.000000 60.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (6,2,6,1, GeometryFromText('LINESTRING(63.000000 60.000000, 73.000000 61.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (7,5,6,1, GeometryFromText('LINESTRING(71.000000 60.000000, 73.000000 61.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (8,4,7,1, GeometryFromText('LINESTRING(68.000000 48.000000, 75.000000 48.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (9,5,7,1, GeometryFromText('LINESTRING(71.000000 60.000000, 75.000000 48.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (10,6,7,1, GeometryFromText('LINESTRING(73.000000 61.000000, 75.000000 48.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (11,1,8,1, GeometryFromText('LINESTRING(61.000000 59.000000, 65.000000 57.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (12,2,8,1, GeometryFromText('LINESTRING(63.000000 60.000000, 65.000000 57.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (13,3,8,2, GeometryFromText('LINESTRING(64.000000 49.000000, 65.000000 57.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (14,4,8,2, GeometryFromText('LINESTRING(68.000000 48.000000, 65.000000 57.000000)', 4326) );
-- insert into roads (rid,from_id,to_id,road_type,centerline) values (15,5,8,1, GeometryFromText('LINESTRING(71.000000 60.000000, 65.000000 57.000000)', 4326) );

-- read in the remaining two data sets using ogr2ogr again.
-- /usr/local/bin/ogr2ogr -f KML pgissc.kml \
-- PG:"host=localhost user=postgres dbname=pgissc" \
-- -sql "select * from kml_stands" -nlt POLYGON -nln stands


--------------------------------------------------------------------------------- 
-- insert some streams (generated arbitrarily)
-- insert into streams (sid,stream_type,centerline) values (1,1,GeometryFromText('LINESTRING(80.000000 65.000000, 55.000000 45.000000)', 4326) );
-- insert into streams (sid,stream_type,centerline) values (2,2,GeometryFromText('LINESTRING(55.000000 65.000000, 67.500000 55.000000)', 4326) );
-- insert into streams (sid,stream_type,centerline) values (3,3,GeometryFromText('LINESTRING(61.250000 70.000000, 61.250000 60.000000)', 4326) );


-- then, create the function to update the forest boundary
-- drop an existing table, st_union the stands, report the time.
--------------------------------------------------------------------------------
-- this function creates a boundary for the forest
-- here, the boundary is the geometric union of the stand polygons
CREATE OR REPLACE FUNCTION update_forest_boundary() RETURNS interval AS $$
DECLARE
  beg_time timestamp;
  end_time timestamp;
BEGIN
  beg_time := timeofday();

  DROP TABLE IF EXISTS boundary CASCADE;
  CREATE TABLE boundary AS SELECT ST_Union(boundary) AS bdry FROM stands;
  ALTER TABLE boundary ADD COLUMN gid serial;
  ALTER TABLE boundary ADD CONSTRAINT gid_pkey PRIMARY KEY  (gid);

  end_time := timeofday();
  return(end_time - beg_time);
END;
$$ language 'plpgsql';

-- generate the boundary polygon
SELECT * FROM update_forest_boundary();

--------------------------------------------------------------------------------
-- next, create a view that can be used to generate the kml file
-- this area is reported in square degrees
-- reproject to oregon state plane blah, blah, blah 
-- srid epsg:2992
SELECT *, area(bdry), area(st_transform(bdry,2992)) FROM boundary;


-- this one is in square degrees and acres (reprojected in oregon state plane, feet)
-- and a bunch of other functions.
SELECT gid, 
       area(bdry) AS sqdeg, 
       area(st_transform(bdry,2992))/43560.0 AS acres,
       area(st_transform(bdry,2992))/43560.0/2.47 AS hectares,

       -- add another srid to demonstrate the influence of units on angles (area)
       
       st_summary(bdry),
       box2d(bdry)
FROM boundary;


--------------------------------------------------------------------------------
-- finally, generate a query to produce the Google Earth File
-- create view rpt_google_earth;
DROP VIEW IF EXISTS kml_stands;
CREATE OR REPLACE VIEW kml_stands AS SELECT 

    s1.id,
    'Stand #' || s1.id AS name,
    s1.strata AS strata,

    -- add the bounding box for gmt maps
    st_xmin( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) ) || '/' || 
    st_xmax( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) ) || '/' || 
    st_ymin( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) ) || '/' || 
    st_ymax( st_box2d( st_expand( st_transform( s1.boundary,4326 ), 0.05 ) ) )  AS gmt_bbox,

    -- add the area, in both acres and hectares
    area(st_transform(s1.boundary,2992))/43560.0 AS acres,
    area(st_transform(s1.boundary,2992))/43560.0/2.47 AS hectares,
    st_summary(s1.boundary),

    -- add the url for the class.
    E'http://www.credativ.us/pg_w_spatial/' as class_site,
    E'http://www.credativ.us/news/2010/06/15/credativ-llc-and-forest-informatics-inc-announce-p/' as shameless_self_promotion,

    -- for ogr2ogr using kml to work well, this needs to be the last entry in the row.
    astext(st_transform(s1.boundary,4326))
FROM 
    stands as s1
ORDER BY 
    s1.id;

--------------------------------------------------------------------------------
-- finally, using ogr2ogr, export the view as a google earth file
-- you can now use the view from within ogr2ogr to generate a google earth file.
-- /usr/local/bin/ogr2ogr -f KML pgissc.kml PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from kml_stands" -nlt POLYGON -nln stands

-- this does not work, so you have to export individual geometries separately.
-- /usr/local/bin/ogr2ogr -f KML pgissc-roads.kml PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from roads" -nlt LINESTRING -nln roads

-- then, finally
-- $ open pgissc.kml


--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 
-- Using PL/R to generate "paper" maps
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 

-- create a simple view to reduce the workload for the query that is used to generate the data.frame
-- that is fed into sqli2[sp,map]
CREATE VIEW RPT_STANDS AS
SELECT 
       *,
       ST_AsText(boundary) as wktgeom, -- this is the data 'type' that is needed by sqli2map()
       st_xmin( boundary) as minx, -- looks like the function also needs the bbox too.
       st_ymin( boundary) as miny,
       st_xmax( boundary) as maxx,
       st_ymax( boundary) as maxy
FROM
	stands
ORDER BY
      id;

-- in short you must begin with a table/view that looks like this (five appended columns)
-- to be able to use the SQLiteMap function sqli2map

-- create the extensions to create stored procedures using R.
-- Thanks to Joe Conway
-- \i /usr/local/pgsql/share/contrib/plr.sql 

-- create some simple function to generate the map plot
-- very simple function 
-- you'll need to move it out of data directory 
create or replace function print_tsp_map ( cid int ) returns text as
$$
	## load the SQLiteMap package to get the sqli2map function
	library( SQLiteMap )

      	## open the database, get the mill, and the prices.
       	stands <- pg.spi.exec( sprintf( "select * from rpt_stands;" ) )         

       	## stands is now a data.frame object that contains HEXEWKB columns
       	## it would be nice if the data.frame could be easily converted into an R spatial object
	## this is the objective of the smaller oscon project
       	stands.map <- sqli2map(geoms=stands, gcol='wktgeom')

	##################################################################
	## this is where we would show some very useful, creative stuff
	## with the spatial capabilites within R, all from within PostgreSQL
	##################################################################


       	## plot a/the map to /usr/local/pgsql/data
       	pdf( "tour2.pdf" )
       	plot( stands.map )
       	dev.off()

       	return( "hi mom" )

$$
language 'plr' strict;


select * from print_tsp_map( 0 );

-- then, from the command line, copy the pdf file to your local directory
-- $ sudo cp /usr/local/pgsql/data/stands-plr.pdf .
-- $ open stands-plr.pdf



--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 
-- Using the stack to perform a more "server-side" analysis using all the parts
--------------------------------------------------------------------------------- 
--------------------------------------------------------------------------------- 



--------------------------------------------------------------------------------
-- translating the postgis data into shapefiles to demonstrate importing data using ogr2ogr
-- rm -frv stands.* 
-- /usr/local/bin/ogr2ogr -progress -f "ESRI Shapefile" stands.shp PG:"host=localhost user=postgres dbname=pgissc" -sql "select id,strata,initage,boundary from stands" -nlt MULTIPOLYGON -nln stands

-- rm -frv roads.* 
-- /usr/local/bin/ogr2ogr -progress -f "ESRI Shapefile" roads.shp PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from roads" -nlt LINESTRING -nln roads -progress



-- rm -frv streams.* 
-- /usr/local/bin/ogr2ogr -progress -f "ESRI Shapefile" streams.shp PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from streams" -nlt LINESTRING -nln streams

-- zip up, send to kelly, get personal geodatabase. 
-- $ tar xvfz pgeo.tar.gz stands.* roads.* streams.*

-- demonstrate using ogr2ogr on the windows side to ingest a personal geodatabase

-- for exporting the files to google earth (for tsp example)
-- /usr/local/bin/ogr2ogr -progress -f "KML" roads.kml PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from roads" -nlt LINESTRING -nln roads
-- /usr/local/bin/ogr2ogr -progress -f "KML" streams.kml PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from streams" -nlt LINESTRING -nln streams


-- this does not work, so you have to export individual geometries separately.
-- /usr/local/bin/ogr2ogr -f KML pgissc.kml PG:"host=localhost user=postgres dbname=pgissc" -nlt LINESTRING -nln roads
-- /usr/local/bin/ogr2ogr -f KML pgissc.kml Lincoln_boundary.shp -nlt POLYGON -nln lincoln




--------------------------------------------------------------------------------
-- these are the file types you can export
-- Supported Formats:
--   -> "ESRI Shapefile" (read/write)
--   -> "MapInfo File" (read/write)
--   -> "UK .NTF" (readonly)
--   -> "SDTS" (readonly)
--   -> "TIGER" (read/write)
--   -> "S57" (read/write)
--   -> "DGN" (read/write)
--   -> "VRT" (readonly)
--   -> "REC" (readonly)
--   -> "Memory" (read/write)
--   -> "BNA" (read/write)
--   -> "CSV" (read/write)
--   -> "GML" (read/write)
--   -> "GPX" (read/write)
--   -> "KML" (read/write)
--   -> "GeoJSON" (read/write)
--   -> "GMT" (read/write)
--   -> "PostgreSQL" (read/write)
--   -> "PCIDSK" (readonly)
--   -> "XPlane" (readonly)
--   -> "AVCBin" (readonly)
--   -> "AVCE00" (readonly)
--   -> "DXF" (read/write)
--   -> "Geoconcept" (read/write)
--   -> "GeoRSS" (read/write)
--   -> "GPSTrackMaker" (read/write)
--   -> "VFK" (readonly)
-- Jeff-Hamanns-MacBook-Pro:trunk hamannj$ 



-- query the PostGIS tables
-- and examine the tabledefs

-- pgissc=# \d+ geometry_columns

-- pgissc=# select * from geometry_columns;
--  f_table_catalog | f_table_schema | f_table_name | f_geometry_column | coord_dimension | srid |     type     
-- -----------------+----------------+--------------+-------------------+-----------------+------+--------------
--                  | public         | stands       | boundary          |               2 | 4326 | MULTIPOLYGON
--                  | public         | stands       | location          |               2 | 4326 | POINT
-- (2 rows)

-- pgissc=# 

-- you can have multiple geometries on one row. this is strange for many people. explain.

-- pgissc=# \d+ spatial_ref_sys

-- pgissc=# \x
-- Expanded display is on.
-- pgissc=# select * from spatial_ref_sys limit 1;
-- -[ RECORD 1 ]--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- srid      | 3819
-- auth_name | EPSG
-- auth_srid | 3819
-- srtext    | GEOGCS["HD1909",DATUM["Hungarian_Datum_1909",SPHEROID["Bessel 1841",6377397.155,299.1528128,AUTHORITY["EPSG","7004"]],TOWGS84[595.48,121.69,515.35,4.115,-2.9383,0.853,-3.408],AUTHORITY["EPSG","1024"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.01745329251994328,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","3819"]]
-- proj4text | +proj=longlat +ellps=bessel +towgs84=595.48,121.69,515.35,4.115,-2.9383,0.853,-3.408 +no_defs 

-- pgissc=# 

-- explain what all that stuff is...

-- it's the same stuff that comes in the prj files with ESRI shapefiles. 

-- Jeff-Hamanns-MacBook-Pro:trunk hamannj$ cat bdry.prj 
-- PROJCS["Lambert_Conformal_Conic",GEOGCS["GCS_North_American_1983",DATUM["D_North_American_1983",SPHEROID["GRS_1980",6378137,298.257222101]],PRIMEM["Greenwich",0],UNIT["Degree",0.017453292519943295]],PROJECTION["Lambert_Conformal_Conic"],PARAMETER["standard_parallel_1",47.33333333333334],PARAMETER["standard_parallel_2",45.83333333333334],PARAMETER["latitude_of_origin",45.33333333333334],PARAMETER["central_meridian",-120.5],PARAMETER["false_easting",1640416.667],PARAMETER["false_northing",0],UNIT["Foot_US",0.30480060960121924]]Jeff-Hamanns-MacBook-Pro:trunk

-- it contains the string representation (EPSG) version of the 
-- http://www.epsg.org/Geodetic.html

-- http://www.epsg.org/guides/docs/G7-1.pdf



--------------------------------------------------------------------------------- 
-- okay, that was cool, but we really need to include raster capabilities since
-- we are going to point our ecosystem-services-scope at our forest of interest
-- and ingest satellite imagery regulary. 
-- we need to install WKTRaster

-- -- step 1. install the wktraster capabilites
-- \i /usr/local/pgsql/share/contrib/rtpostgis.sql 

-- SELECT PostGIS_Raster_Lib_Version();

-- --------------------------------------------------------------------------------- 
-- -- step 2. now, create the dummy_raster table (by hand)

-- CREATE TABLE dummy_rast(rid integer, rast raster);
-- INSERT INTO dummy_rast(rid, rast)
-- VALUES (1,
-- ('01' -- little endian (uint8 ndr)
-- || 
-- '0000' -- version (uint16 0)
-- ||
-- '0000' -- nBands (uint16 0)
-- ||
-- '0000000000000040' -- scaleX (float64 2)
-- ||
-- '0000000000000840' -- scaleY (float64 3)
-- ||
-- '000000000000E03F' -- ipX (float64 0.5)
-- ||
-- '000000000000E03F' -- ipY (float64 0.5)
-- ||
-- '0000000000000000' -- skewX (float64 0)
-- ||
-- '0000000000000000' -- skewY (float64 0)
-- ||
-- '00000000' -- SRID (int32 0)
-- ||
-- '0A00' -- width (uint16 10)
-- ||
-- '1400' -- height (uint16 20)
-- )::raster
-- ),
-- -- Raster: 5 x 5 pixels, 3 bands, PT_8BUI pixel type, NODATA = 0
-- (2,  ('01000003009A9999999999A93F9A9999999999A9BF000000E02B274A' ||
-- '41000000007719564100000000000000000000000000000000FFFFFFFF050005000400FDFEFDFEFEFDFEFEFDF9FAFEF' ||
-- 'EFCF9FBFDFEFEFDFCFAFEFEFE04004E627AADD16076B4F9FE6370A9F5FE59637AB0E54F58617087040046566487A1506CA2E3FA5A6CAFFBFE4D566DA4CB3E454C5665')::raster);


--------------------------------------------------------------------------------
-- step 3. now, import some real data using the gdal2wktraster.py script

-- not gonna happen.


-- -- this should probably now go into a separate file that can be sourced on any rufus
-- -- database with a stands table
-- --------------------------------------------------------------------------------
-- -- adjacency list entries
-- --------------------------------------------------------------------------------
-- create table adj_list (
-- 	pid integer,	  -- polygon id
-- 	aid integer,	  -- adj. polygon id
-- 	relate text,	  -- postgis relate
-- 	st_length double precision, -- length of common edge
-- 	primary key (pid,aid)
-- );

-- COMMENT ON table adj_list  IS 'a table that contains a list of adjacenct forest polygons, for configuration c';
-- COMMENT ON column adj_list.pid IS 'the polygon id for this entry';
-- COMMENT ON column adj_list.aid IS 'the adjacenct polygon id for this entry';
-- COMMENT ON column adj_list.relate IS 'is the resulting postgis relate text for this entry';
-- COMMENT ON column adj_list.st_length IS 'is the length of the side that is common between pid and aid';

--  --------------------------------------------------------------------------------
--  -- a function to create the adjacency list for stands
--  --------------------------------------------------------------------------------
--  create or replace function update_adj_list( mindist real ) returns interval as 
--  $$
--  declare
-- 	 beg_time timestamp;
-- 	 end_time timestamp;
--  begin
--  beg_time := timeofday();
-- -- delete from adj_list where cid=1;
-- delete from adj_list;
--  insert into 
--       adj_list
--  select 
-- --     1   as cid,
--    t1.id as pid,
--    t2.id as aid,
--    Relate( t1.boundary, t2.boundary ) as relate,
--    ST_Length( ST_Intersection( t1.boundary, t2.boundary ) ) as st_length
--  from
--    stands t1,
--    stands t2
--  where
--     -- you need to account for when there's a buffering distance between stands
--     -- buffering??? -- not now. mindist = 0.0?
--     intersects( t1.boundary, t2.boundary ) and
--     t1.boundary && t2.boundary and 
--     Equals( t1.boundary, t2.boundary ) is FALSE and
--    ST_Length( ST_Intersection( t1.boundary, t2.boundary ) ) > 0.0
--  order by 
-- 	 t1.id,
-- 	 t2.id;
--  end_time := timeofday();
--  return( end_time - beg_time );
--  END;
--  $$
--  language 'plpgsql';

-- -- now, update the adjcency list.
-- select * from update_adj_list( 0 );


-- define the table that will match the returning data.frame
DROP TABLE IF EXISTS events CASCADE;
CREATE TABLE events
(
  seqid int not null primary key, -- visit sequence #
  plotid int, -- original plot id
  bearing real, -- bearing to next waypoint
  distance real,  -- distance to next waypoint
  velocity real, -- velocity of travel, in nm/hr
  traveltime real, -- travel time to next event
  loitertime real, -- how long to hang out
  totaltraveldist real, -- cummulative distance
  totaltraveltime real -- cummulaative time
);

-- you can add geometry too
SELECT AddGeometryColumn('','events','location','4326','POINT',2);
CREATE INDEX "events_location_gist" ON "events" USING gist ("location" gist_geometry_ops);

CREATE TABLE plr_modules (
  modseq int4 primary key,
  modsrc text
);

INSERT INTO plr_modules
  VALUES (0, $$
  make.route <-function(tour, waypts, dist.matrix) {
    velocity <- 500.0
    starts <- tour[1:(length(tour))-1]
    stops <- tour[2:(length(tour))]
    dist.vect <- diag( as.matrix( dist.matrix )[starts,stops] )
    last.leg <- as.matrix( dist.matrix )[tour[length(tour)],tour[1]]
    dist.vect <- c(dist.vect, last.leg )
    delta.x <- diff( waypts[tour,]$x )
    delta.y <- diff( waypts[tour,]$y )
    bearings <- atan( delta.x/delta.y ) * 180 / pi
    bearings <- c(bearings,0)
    for( i in 1:(length(tour)-1) ) {
      if( delta.x[i] > 0.0 && delta.y[i] > 0.0 ) bearings[i] <- bearings[i]
      if( delta.x[i] > 0.0 && delta.y[i] < 0.0 ) bearings[i] <- 180.0 + bearings[i]
      if( delta.x[i] < 0.0 && delta.y[i] > 0.0 ) bearings[i] <- 360.0 + bearings[i]
      if( delta.x[i] < 0.0 && delta.y[i] < 0.0 ) bearings[i] <- 180 + bearings[i]
    }
    route <- data.frame(seq=1:length(tour), ptid=tour, bearing=bearings, dist.vect=dist.vect,
                        velocity=velocity, travel.time=dist.vect/velocity, loiter.time=0.5)
    route$total.travel.dist <- cumsum(route$dist.vect)
    route$total.travel.time <- cumsum(route$travel.time+route$loiter.time)
    route$location <- waypts[tour,]$location
    return(route)
  }$$
);

INSERT INTO plr_modules
  VALUES (1, $$
  make.map <-function(tour, waypts, mapname) {
    require(maps)

    jpeg(file=mapname, width = 480, height = 480, pointsize = 10, quality = 75)
    map('world2', xlim = c(20, 120), ylim=c(20,80) )
    map.axes()
    grid()
    arrows(waypts[tour[1:(length(tour)-1)],]$x, waypts[tour[1:(length(tour)-1)],]$y,
           waypts[tour[2:(length(tour))],]$x, waypts[tour[2:(length(tour))],]$y,
           angle=10, lwd=1, length=.15, col="red")

    points( waypts$x, waypts$y, pch=3, cex=2 )
    points( waypts$x, waypts$y, pch=20, cex=0.8 )

    text(  waypts$x+2, waypts$y+2, as.character( waypts$id  ), cex=0.8 )
    title( "TSP soln using PL/R" )
    dev.off()
  }$$
);
SELECT reload_plr_modules();

CREATE OR REPLACE FUNCTION solve_tsp(makemap bool, mapname text) RETURNS SETOF events AS
$$
  require(TSP)
  require(fields)

  sql.str <- "select id, st_x(location) as x, st_y(location) as y, location from stands;" 
  waypts <- pg.spi.exec(sql.str)

  dist.matrix <-  rdist.earth(waypts[,2:3], R=3949.0)
  rtsp <- TSP(dist.matrix)
  soln <- solve_TSP(rtsp)
  tour <- as.vector(soln)
  pg.thrownotice( paste("tour.dist=", attributes(soln)$tour_length))

  route <- make.route(tour, waypts, dist.matrix)
  if (makemap) {
    make.map(tour, waypts, mapname)
  }

  return(route)
$$
LANGUAGE 'plr' STRICT;



-- test the results
SELECT * FROM solve_tsp(true, 'tsp.jpg');


-- also check out the map
-- $ sudo cp /usr/local/pgsql/data/tour-with-map-from-plr.pdf .
-- $ sudo chmod 744 tour-with-map-from-plr.pdf
-- $ open tour-with-map-from-plr.pdf
