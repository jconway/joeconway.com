/*
 * Example code from PgWest 2010
 *
 * Joe Conway <mail@joeconway.com>
 * Jeff Hamann <jeff.hamann@forestinformatics.com>
 * Copyright (c) 2010, Joe Conway, Jeff Hamann
 * ALL RIGHTS RESERVED;
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without a written agreement
 * is hereby granted, provided that the above copyright notice and this
 * paragraph and the following two paragraphs appear in all copies.
 *
 * IN NO EVENT SHALL THE AUTHOR OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE AUTHOR OR DISTRIBUTORS HAVE BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHOR AND DISTRIBUTORS SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE AUTHOR AND DISTRIBUTORS HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 */

--	$Id$	

-- rufus.r conversion utility
-- constructing data for  leuschner to  leuschner.sql 
-- exporting data to  leuschner.sql 


CREATE LANGUAGE plpgsql;

-- then, load postgis functions, spatial reference systems, and function comments
\i /usr/local/pgsql/share/contrib/postgis-1.5/postgis.sql 
\i /usr/local/pgsql/share/contrib/postgis-1.5/spatial_ref_sys.sql 
\i /usr/local/pgsql/share/contrib/plr.sql 


CREATE TABLE stands
(
    id serial primary key,	-- A_{b}
    strata integer not null, -- A^{s}_{b}
    initage integer -- A^{a}_{b}
);


-- create a field named boundary, using SRID EPSG:4326 in 2 dimensions
-- and create an index
SELECT AddGeometryColumn('','stands','boundary','2286','MULTIPOLYGON',2);
CREATE INDEX "stands_boundary_gist" ON "stands" using gist ("boundary" gist_geometry_ops);

-- and create a point that will represent a landing, using SRID EPSG:4326 in 2 dimensions
SELECT AddGeometryColumn('','stands','location','2286','POINT',2);
CREATE INDEX "stands_location_gist" ON "stands" using gist ("location" gist_geometry_ops);

-- and add a comment
COMMENT ON TABLE stands IS 'a table that contains stand data for the forest';


insert into stands (id,strata,initage,boundary,location) values (1,1,30,GeometryFromText('MULTIPOLYGON(((  862620.975674 412620.975674,  877379.024326 412620.975674,  877379.024326 427379.024326,  862620.975674 427379.024326, 862620.975674 412620.975674 )))', 2286) ,GeometryFromText('POINT( 870000.000000 420000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (2,2,40,GeometryFromText('MULTIPOLYGON(((  882620.975674 432620.975674,  897379.024326 432620.975674,  897379.024326 447379.024326,  882620.975674 447379.024326, 882620.975674 432620.975674 )))', 2286) ,GeometryFromText('POINT( 890000.000000 440000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (3,3,50,GeometryFromText('MULTIPOLYGON(((  902620.975674 452620.975674,  917379.024326 452620.975674,  917379.024326 467379.024326,  902620.975674 467379.024326, 902620.975674 452620.975674 )))', 2286) ,GeometryFromText('POINT( 910000.000000 460000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (4,4,60,GeometryFromText('MULTIPOLYGON(((  922620.975674 472620.975674,  937379.024326 472620.975674,  937379.024326 487379.024326,  922620.975674 487379.024326, 922620.975674 472620.975674 )))', 2286) ,GeometryFromText('POINT( 930000.000000 480000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (5,5,70,GeometryFromText('MULTIPOLYGON(((  841925.155602 461925.155602,  878074.844398 461925.155602,  878074.844398 498074.844398,  841925.155602 498074.844398, 841925.155602 461925.155602 )))', 2286) ,GeometryFromText('POINT( 860000.000000 480000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (6,6,80,GeometryFromText('MULTIPOLYGON(((  895241.951349 505241.951349,  924758.048651 505241.951349,  924758.048651 534758.048651,  895241.951349 534758.048651, 895241.951349 505241.951349 )))', 2286) ,GeometryFromText('POINT( 910000.000000 520000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (7,7,90,GeometryFromText('MULTIPOLYGON(((  848568.464670 528568.464670,  871431.535330 528568.464670,  871431.535330 551431.535330,  848568.464670 551431.535330, 848568.464670 528568.464670 )))', 2286) ,GeometryFromText('POINT( 860000.000000 540000.000000 )', 2286 ));
insert into stands (id,strata,initage,boundary,location) values (8,8,100,GeometryFromText('MULTIPOLYGON(((  925333.095244 415333.095244,  934666.904756 415333.095244,  934666.904756 424666.904756,  925333.095244 424666.904756, 925333.095244 415333.095244 )))', 2286) ,GeometryFromText('POINT( 930000.000000 420000.000000 )', 2286 ));



CREATE TABLE yields
(
    stand integer,
    period integer,
    age integer,
    vol real,

    primary key (stand,period)
);

insert into yields (stand,period,age,vol) values (1,1,30,3.200000);
insert into yields (stand,period,age,vol) values (1,2,40,6.100000);
insert into yields (stand,period,age,vol) values (1,3,50,8.300000);
insert into yields (stand,period,age,vol) values (1,4,60,10.100000);
insert into yields (stand,period,age,vol) values (1,5,70,11.600000);
insert into yields (stand,period,age,vol) values (1,6,80,12.900000);
insert into yields (stand,period,age,vol) values (2,1,40,6.100000);
insert into yields (stand,period,age,vol) values (2,2,50,8.300000);
insert into yields (stand,period,age,vol) values (2,3,60,10.100000);
insert into yields (stand,period,age,vol) values (2,4,70,11.600000);
insert into yields (stand,period,age,vol) values (2,5,80,12.900000);
insert into yields (stand,period,age,vol) values (2,6,90,14.100000);
insert into yields (stand,period,age,vol) values (3,1,50,8.300000);
insert into yields (stand,period,age,vol) values (3,2,60,10.100000);
insert into yields (stand,period,age,vol) values (3,3,70,11.600000);
insert into yields (stand,period,age,vol) values (3,4,80,12.900000);
insert into yields (stand,period,age,vol) values (3,5,90,14.100000);
insert into yields (stand,period,age,vol) values (3,6,100,15.100000);
insert into yields (stand,period,age,vol) values (4,1,60,10.100000);
insert into yields (stand,period,age,vol) values (4,2,70,11.600000);
insert into yields (stand,period,age,vol) values (4,3,80,12.600000);
insert into yields (stand,period,age,vol) values (4,4,90,14.100000);
insert into yields (stand,period,age,vol) values (4,5,100,15.100000);
insert into yields (stand,period,age,vol) values (4,6,110,16.000000);
insert into yields (stand,period,age,vol) values (5,1,70,11.600000);
insert into yields (stand,period,age,vol) values (5,2,80,12.600000);
insert into yields (stand,period,age,vol) values (5,3,90,14.100000);
insert into yields (stand,period,age,vol) values (5,4,100,15.100000);
insert into yields (stand,period,age,vol) values (5,5,110,16.000000);
insert into yields (stand,period,age,vol) values (5,6,120,16.900000);
insert into yields (stand,period,age,vol) values (6,1,80,12.900000);
insert into yields (stand,period,age,vol) values (6,2,90,14.100000);
insert into yields (stand,period,age,vol) values (6,3,100,15.100000);
insert into yields (stand,period,age,vol) values (6,4,110,16.000000);
insert into yields (stand,period,age,vol) values (6,5,120,16.900000);
insert into yields (stand,period,age,vol) values (6,6,130,17.700000);
insert into yields (stand,period,age,vol) values (7,1,90,14.100000);
insert into yields (stand,period,age,vol) values (7,2,100,15.100000);
insert into yields (stand,period,age,vol) values (7,3,110,16.000000);
insert into yields (stand,period,age,vol) values (7,4,120,16.900000);
insert into yields (stand,period,age,vol) values (7,5,130,17.700000);
insert into yields (stand,period,age,vol) values (7,6,140,18.400000);
insert into yields (stand,period,age,vol) values (8,1,100,15.100000);
insert into yields (stand,period,age,vol) values (8,2,110,16.000000);
insert into yields (stand,period,age,vol) values (8,3,120,16.900000);
insert into yields (stand,period,age,vol) values (8,4,130,17.700000);
insert into yields (stand,period,age,vol) values (8,5,140,18.400000);
insert into yields (stand,period,age,vol) values (8,6,150,19.100000);


vacuum full analyze;


-- now add the plr function for solving the harvest scheduling problem.
CREATE OR REPLACE FUNCTION max_woodflow_lp ( int ) returns numeric AS
$$

  rm( list=ls() )
  if(!require(glpk, quietly=TRUE)) install.packages("glpk", repos="http://cran.r-project.org")

  T <- 6     # six periods

  ## load your libraries, prep data, and solve
  sql.str <- "select *,st_area(boundary)/43560.0 as acres from stands;"
  stands <- pg.spi.exec( sql.str )         	
  stand.acres <- stands$acres;
  A <- nrow( stands )

  sql.str <- "select * from yields order by stand, period;"
  leusch.ylds <- pg.spi.exec( sql.str )         	

  ## create the problem and assign the name and
  ## set the direction of the search (max/min)
  leusch.lp <- lpx_create_prob()
  lpx_set_prob_name(leusch.lp, "leuschner")
  lpx_set_obj_dir(leusch.lp, LPX_MAX)

  ## start building the problem matrix parts
  lpx_add_cols(leusch.lp, nrow( leusch.ylds ))

  ## create the labels for the decision variables
  ## which are the column names
  leusch.ylds$dv <- paste("a", 
                        leusch.ylds$stand, 
                        leusch.ylds$period, 
                        sep="")

  ## set the column names
  for( t in 1:nrow(leusch.ylds)) {
    label <- leusch.ylds[t,]$dv
    lpx_set_col_name(leusch.lp, t, label)
  }

  ## set the column bounds
  for(t in 1:nrow(leusch.ylds)) {
    lpx_set_col_bnds(leusch.lp, t, LPX_LO, 0.0, 0.0)
  }

  ## set the objective function coefficients
  for(t in 1:nrow( leusch.ylds)) {
    lpx_set_obj_coef(leusch.lp, t, leusch.ylds[t,]$vol)
  }

  ## add the rows. you need one for each stand
  lpx_add_rows(leusch.lp, length(stand.acres))

  ## add the constraints for the areas
  acre.consts <- t( kronecker(diag(length(stand.acres)), 
                            as.matrix( rep(1,T))))

  val <- rep(1, T)  # this is the value of the constraint
  ## loop over the stands to generate 
  ## the idx is the index for the set of rows
  ## we are trying to set the coefficients for
  for(i in 1:length(stand.acres)) {
    idx <- rep(0, T)  # this is the index of the col coeffs
    ## manually create the index using id
    ## and assign row i, column j stored as idx[id]
    id <- 1
    for(j in 1:ncol(acre.consts)) {
      if(acre.consts[i,j] != 0.0) {
        idx[id] <- j
        id <- id + 1
      }
    }  
 
    ## set the constraint row name
    lpx_set_row_name(leusch.lp, i, paste("s", i, sep=""))
  
    ## set the upper bound on the acres for this stand
    ## to make sure no more than stand.acres[i] are cut
    lpx_set_row_bnds(leusch.lp, i, LPX_UP, 0.0, stand.acres[i])
  
    ## set matrix row coefficients (?glp_set_mat_row)
    lpx_set_mat_row(leusch.lp, i, length(val), idx, val)  
  }

  ## set the target acres for each period and add those rows
  target.acres <- rep(14000, T)
  ##target.acres <- rep( cid, T)
  lpx_add_rows(leusch.lp, length(target.acres))

  val <- rep(1,A) ## a vector of 8 ones.
  for(i in 1:length(target.acres)) {
     idx <- as.numeric(rownames(subset(leusch.ylds, period == i)))
    lpx_set_row_name(leusch.lp, 
                   i + length(stand.acres), 
                   paste("tac", i, sep="" ))
    lpx_set_row_bnds(leusch.lp, 
                   i + length(stand.acres), 
                   LPX_FX, 
                   target.acres[i], 
                   target.acres[i])
    lpx_set_mat_row(leusch.lp, 
                  i + length(stand.acres), 
                  length(val), 
                  idx, 
                  val)
  }

  ## solve it, get the obj val
  lpx_simplex(leusch.lp)

  ## get the objective function value
  leusch.obj <- lpx_get_obj_val(leusch.lp)

  ## write a couple of archives
  lpx_write_mps(leusch.lp, "leuschner.mps")
  lpx_write_cpxlp(leusch.lp, "leuschner.xlp")

  ## delete the problem, free the pointer
  lpx_delete_prob(leusch.lp)

  return( leusch.obj )
$$
language 'plr' strict;


-- generate and solve the LP with one function now.
select * from solve_lp(1);


--------------------------------------------------------------------------------
-- now add the plr function for solving the harvest scheduling problem.

-- add column and row reports to the plr_modules



-- create the plr_modules
CREATE TABLE plr_modules (
  modseq int4 primary key,
  modsrc text
);



-- delete from plr_modules where modseq = 41;
INSERT INTO plr_modules
  VALUES (41, 
$$
get_row_report <- function( lp ) {
  ## get the number of columns
  nrows <- lpx_get_num_rows( lp )
  ## build the table for the rows
  r <- NULL
  for( i in 1:nrows ) {
    r <- rbind( r,
               as.data.frame( cbind( lpx_get_row_name( lp, i ),
                                    lpx_get_row_stat( lp, i ),
                                    lpx_get_row_prim( lp, i ),
                                    lpx_get_row_lb( lp, i ),
                                    lpx_get_row_ub( lp, i ),
                                    lpx_get_row_dual( lp, i ),
                                    glpk_strerror(lpx_get_row_type(lp,i))
                                    )
                             )
               )
  }
  names(r) <- c("name","status","prim","lb","ub","dual","strerr" )
  rownames( r ) <- 1:nrows
  r
}

$$
);

INSERT INTO plr_modules
  VALUES (42, 
$$

get_col_report <- function( lp ) {

  ncols <- lpx_get_num_cols( lp )
  c <- NULL
  for( i in 1:ncols ) {
    c <- rbind( c,
               as.data.frame( cbind( I(lpx_get_col_name( lp, i )),
                                    I(lpx_get_col_stat( lp, i ) ),
                                    I(lpx_get_col_prim( lp, i ) ),
                                    I(lpx_get_col_lb( lp, i ) ),
                                    I(lpx_get_col_ub( lp, i ) ),
                                    I(lpx_get_col_dual( lp, i ) ),
                                    I(lpx_get_col_b_ind( lp, i ) ),
                                    I(lpx_get_col_type( lp, i ) )
                                    )
                             )
               )
  }
  
  
  names(c) <- c("name","status","activity","lb","ub","dual","b_ind","type" )
  rownames( c ) <- 1:ncols

  c
}

$$
);



-- reload the modules again
select * from reload_plr_modules();


--------------------------------------------------------------------------------
create table harvests (
       stand int,
       period int,
       harvestac real
);


CREATE OR REPLACE FUNCTION max_woodflow_lp2 ( int ) returns setof harvests AS
$$

  rm( list=ls() )
  if(!require(glpk, quietly=TRUE)) install.packages("glpk", repos="http://cran.r-project.org")

  T <- 6     # six periods

  ## load your libraries, prep data, and solve
  sql.str <- "select *,st_area(boundary)/43560.0 as acres from stands;"
  stands <- pg.spi.exec( sql.str )         	
  stand.acres <- stands$acres;
  A <- nrow( stands )

  sql.str <- "select * from yields order by stand, period;"
  leusch.ylds <- pg.spi.exec( sql.str )         	

  ## create the problem and assign the name and
  ## set the direction of the search (max/min)
  leusch.lp <- lpx_create_prob()
  lpx_set_prob_name(leusch.lp, "leuschner")
  lpx_set_obj_dir(leusch.lp, LPX_MAX)

  ## start building the problem matrix parts
  lpx_add_cols(leusch.lp, nrow( leusch.ylds ))

  ## create the labels for the decision variables
  ## which are the column names
  leusch.ylds$dv <- paste("a", 
                        leusch.ylds$stand, 
                        leusch.ylds$period, 
                        sep="")

  ## set the column names
  for( t in 1:nrow(leusch.ylds)) {
    label <- leusch.ylds[t,]$dv
    lpx_set_col_name(leusch.lp, t, label)
  }

  ## set the column bounds
  for(t in 1:nrow(leusch.ylds)) {
    lpx_set_col_bnds(leusch.lp, t, LPX_LO, 0.0, 0.0)
  }

  ## set the objective function coefficients
  for(t in 1:nrow( leusch.ylds)) {
    lpx_set_obj_coef(leusch.lp, t, leusch.ylds[t,]$vol)
  }

  ## add the rows. you need one for each stand
  lpx_add_rows(leusch.lp, length(stand.acres))

  ## add the constraints for the areas
  acre.consts <- t( kronecker(diag(length(stand.acres)), 
                            as.matrix( rep(1,T))))

  val <- rep(1, T)  # this is the value of the constraint
  ## loop over the stands to generate 
  ## the idx is the index for the set of rows
  ## we are trying to set the coefficients for
  for(i in 1:length(stand.acres)) {
    idx <- rep(0, T)  # this is the index of the col coeffs
    ## manually create the index using id
    ## and assign row i, column j stored as idx[id]
    id <- 1
    for(j in 1:ncol(acre.consts)) {
      if(acre.consts[i,j] != 0.0) {
        idx[id] <- j
        id <- id + 1
      }
    }  
 
    ## set the constraint row name
    lpx_set_row_name(leusch.lp, i, paste("s", i, sep=""))
  
    ## set the upper bound on the acres for this stand
    ## to make sure no more than stand.acres[i] are cut
    lpx_set_row_bnds(leusch.lp, i, LPX_UP, 0.0, stand.acres[i])
  
    ## set matrix row coefficients (?glp_set_mat_row)
    lpx_set_mat_row(leusch.lp, i, length(val), idx, val)  
  }

  ## set the target acres for each period and add those rows
  target.acres <- rep(14000, T)
  ##target.acres <- rep( cid, T)
  lpx_add_rows(leusch.lp, length(target.acres))

  val <- rep(1,A) ## a vector of 8 ones.
  for(i in 1:length(target.acres)) {
     idx <- as.numeric(rownames(subset(leusch.ylds, period == i)))
    lpx_set_row_name(leusch.lp, 
                   i + length(stand.acres), 
                   paste("tac", i, sep="" ))
    lpx_set_row_bnds(leusch.lp, 
                   i + length(stand.acres), 
                   LPX_FX, 
                   target.acres[i], 
                   target.acres[i])
    lpx_set_mat_row(leusch.lp, 
                  i + length(stand.acres), 
                  length(val), 
                  idx, 
                  val)
  }

  ## solve it, get the obj val
  lpx_simplex(leusch.lp)

  ## get the objective function value
  leusch.obj <- lpx_get_obj_val(leusch.lp)

  ## write a couple of archives
  lpx_write_mps(leusch.lp, "leuschner.mps")
  lpx_write_cpxlp(leusch.lp, "leuschner.xlp")

  ## extract out the harvest volumes and periods
  ## from the solution
  leusch.col.rpt <- get_col_report(leusch.lp);
  ac.per <- matrix(as.numeric(as.matrix(I(leusch.col.rpt$activity))), T, A);
  ret.frame <- NULL
  for( i in 1:T ) {
    for( j in 1:A ) {
      if( ac.per[i,j] > 0.0 ) {
        ret.frame <- rbind( ret.frame, data.frame( stand=j, period=i, harvestac=ac.per[i,j] ) )
      }
    }
  }

  ## delete the problem, free the pointer
  lpx_delete_prob(leusch.lp)

  return( ret.frame )
$$
language 'plr' strict;


-- generate the table that contains the areas harvested in each period for each stand
select * from max_woodflow_lp2 ( 1 );

-- confirm the strict equality constraint is met
select period,sum(harvestac) from max_woodflow_lp2 ( 1 ) group by period order by period;



-- you should find leuschner.mps and leuschner.xlp in /usr/local/pgsql/data

-- you can now show some maps using ogr2ogr

-- create a query to show the schedule.


--------------------------------------------------------------------------------
-- finally, using ogr2ogr, export the view as a google earth file
-- you can now use the view from within ogr2ogr to generate a google earth file.
-- /usr/local/bin/ogr2ogr -f KML adv.kml PG:"host=localhost user=postgres dbname=adv" -sql "select *,as_text(boundary) from stands" -nlt POLYGON -nln stands



-- if(!require(RPostgreSQL, quietly=TRUE)) install.packages("RPostgreSQL")

-- drv <- dbDriver("PostgreSQL")
-- con <- dbConnect(drv, dbname="tsp",user="postgres",host="localhost")
-- sql.str <- "select * from pg_stats;"
-- rs <- dbSendQuery(con, statement = sql.str );
-- waypts <- fetch(rs, n = -1) # extract all rows
-- dbDisconnect( con )

-- pdf( "pg_stats_rpt.pdf" )
-- plot( waypts[,c(4,5,6,10)] )
-- dev.off()




-- now add the plr function for solving the harvest scheduling problem.
-- CREATE OR REPLACE FUNCTION plot_pg_stats( pdfname text ) returns text AS
-- $$

-- ## this seems to clean out the function arguments, so dont do this for plr functions
-- ##  rm( list=ls() )

--   ## works
--   sql.str <- "select null_frac,avg_width,n_distinct,correlation from pg_stats;"
  
--   ## doesnt work
--   ##sql.str <- "select * from pg_stats;"

--   pg.stats <- pg.spi.exec( sql.str ) 
        
--   pg.thrownotice( pdfname )	
--   pdf( pdfname )
--   plot( pg.stats )
--   ##plot( pg.stats[,c(4,5,6,10)] )
--   dev.off()

--   return( pdfname )

-- $$
-- language 'plr' strict;


select * from plot_pg_stats( '/usr/local/pgsql/data/pg_stats.pdf' );





