/*
 * Example code from PgWest 2010
 *
 * Joe Conway <mail@joeconway.com>
 * Jeff Hamann <jeff.hamann@forestinformatics.com>
 * Copyright (c) 2010, Joe Conway, Jeff Hamann
 * ALL RIGHTS RESERVED;
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose, without fee, and without a written agreement
 * is hereby granted, provided that the above copyright notice and this
 * paragraph and the following two paragraphs appear in all copies.
 *
 * IN NO EVENT SHALL THE AUTHOR OR DISTRIBUTORS BE LIABLE TO ANY PARTY FOR
 * DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
 * LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
 * DOCUMENTATION, EVEN IF THE AUTHOR OR DISTRIBUTORS HAVE BEEN ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * THE AUTHOR AND DISTRIBUTORS SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS
 * ON AN "AS IS" BASIS, AND THE AUTHOR AND DISTRIBUTORS HAS NO OBLIGATIONS TO
 * PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 *
 */

--	$Id: tsp.sql 240 2010-11-12 17:09:37Z hamannj $	

-- this file contains the tsp example for the stack 

-- Assuming: 
-- 1) you already have the stack built

-- this script performs the following functions:
-- 1) creates the stand table 
-- 2) creates a function that solves the tsp
-- 3) show example of calling the function (version 1)
-- 4) create an EVENTS table to hold the results (don't store for now)
-- 5) generate alternative solution representation (version 2)
-- 6) use the results to generate a GPX file as well

CREATE LANGUAGE plpgsql;

-- then, load postgis functions, spatial reference systems, and function comments
\i /usr/local/pgsql/share/contrib/postgis-1.5/postgis.sql 
\i /usr/local/pgsql/share/contrib/postgis-1.5/spatial_ref_sys.sql 
\i /usr/local/pgsql/share/contrib/plr.sql 


--------------------------------------------------------------------------------- 
-- then, define your tables.
-- here, we create a table for the stand stands (polygons), roads (lines) and streams (lines)
CREATE TABLE stands
(
    id serial primary key,	-- A_{b}
    strata integer not null, -- A^{s}_{b}
    initage integer -- A^{a}_{b}
);


-- create a field named boundary, using SRID EPSG:4326 in 2 dimensions
-- and create an index
SELECT AddGeometryColumn('','stands','boundary','4326','MULTIPOLYGON',2);
CREATE INDEX "stands_boundary_gist" ON "stands" using gist ("boundary" gist_geometry_ops);

-- and create a point that will represent a landing, using SRID EPSG:4326 in 2 dimensions
SELECT AddGeometryColumn('','stands','location','4326','POINT',2);
CREATE INDEX "stands_location_gist" ON "stands" using gist ("location" gist_geometry_ops);

-- and add a comment
COMMENT ON TABLE stands IS 'a table that contains stand data for the forest';

-- ingest the data.
-- add data to the stands table using insert commands constructed by hand
INSERT INTO stands (id,strata,initage,boundary,location) VALUES
 (1,1,1,GeometryFromText('MULTIPOLYGON(((  59.250000 65.000000,  55.000000 65.000000,  55.000000 51.750000,  60.735294 53.470588,  62.875000 57.750000, 59.250000 65.000000 )))', 4326) ,GeometryFromText('POINT( 61.000000 59.000000 )', 4326 ))
,(2,2,1,GeometryFromText('MULTIPOLYGON(((  67.000000 65.000000,  59.250000 65.000000,  62.875000 57.750000,  67.000000 60.500000, 67.000000 65.000000 )))', 4326) ,GeometryFromText('POINT( 63.000000 60.000000 )', 4326 ))
,(3,3,1,GeometryFromText('MULTIPOLYGON(((  67.045455 52.681818,  60.735294 53.470588,  55.000000 51.750000,  55.000000 45.000000,  65.125000 45.000000, 67.045455 52.681818 )))', 4326) ,GeometryFromText('POINT( 64.000000 49.000000 )', 4326 ))
,(4,4,1,GeometryFromText('MULTIPOLYGON(((  71.500000 53.500000,  70.357143 53.785714,  67.045455 52.681818,  65.125000 45.000000,  71.500000 45.000000, 71.500000 53.500000 )))', 4326) ,GeometryFromText('POINT( 68.000000 48.000000 )', 4326 ))
,(5,5,1,GeometryFromText('MULTIPOLYGON(((  69.750000 65.000000,  67.000000 65.000000,  67.000000 60.500000,  70.357143 53.785714,  71.500000 53.500000,  74.928571 54.642857, 69.750000 65.000000 )))', 4326) ,GeometryFromText('POINT( 71.000000 60.000000 )', 4326 ))
,(6,6,1,GeometryFromText('MULTIPOLYGON(((  80.000000 65.000000,  69.750000 65.000000,  74.928571 54.642857,  80.000000 55.423077, 80.000000 65.000000 )))', 4326) ,GeometryFromText('POINT( 73.000000 61.000000 )', 4326 ))
,(7,7,1,GeometryFromText('MULTIPOLYGON(((  80.000000 55.423077,  74.928571 54.642857,  71.500000 53.500000,  71.500000 45.000000,  80.000000 45.000000, 80.000000 55.423077 )))', 4326) ,GeometryFromText('POINT( 75.000000 48.000000 )', 4326 ))
,(8,8,1,GeometryFromText('MULTIPOLYGON(((  67.000000 60.500000,  62.875000 57.750000,  60.735294 53.470588,  67.045455 52.681818,  70.357143 53.785714, 67.000000 60.500000 )))', 4326) ,GeometryFromText('POINT( 65.000000 57.000000 )', 4326 ))
;



-- this function uses pl/r to solve the tsp, but only returns the tour length

drop function if exists solve_tsp( int );
create or replace function solve_tsp ( cid int ) returns numeric as
$$

	## load your libraries and data
	if(!require(TSP, quietly=TRUE)) install.packages("TSP")
	if(!require(fields, quietly=TRUE)) install.packages("fields")
	
	sql.str <- "select id as pt, st_x(location) as x, st_y(location) as y from stands;"
       	waypts <- pg.spi.exec( sql.str )         
	
	## compute the distance matrix (not this one)
	## dist.matrix <- dist( waypts[,c(2,3)], upper=TRUE )
	## use the fields version
	## statute miles, earth radius, etc. as inputs
	dist.matrix <-  rdist.earth( waypts[,2:3], R=3949.0 )

	## prepare the data for the solve_tsp function
	rtsp <- TSP( dist.matrix )

	## solve it, and
	soln <- solve_TSP( rtsp )

	## return the length of the tour
	return( attributes( soln )$tour_length )

$$
language 'plr' strict;


-- now call the function and the map should be created in /usr/local/pgsql/data
select * from solve_tsp(1) as tour_length;

-- which is nice, but we also want to part out the solution and store the pieces.
-- modifying the function to return a string representing the order of the waypts
create or replace function solve_tsp ( lat numeric, lon numeric, radius numeric  ) returns text as
$$

	## load your libraries and data
	if(!require(TSP, quietly=TRUE)) install.packages("TSP")
	if(!require(fields, quietly=TRUE)) install.packages("fields")
	
	sql.str <- "select id as pt, st_x(location) as x, st_y(location) as y from stands;"
       	waypts <- pg.spi.exec( sql.str )         
	
	## compute the distance matrix (not this one)
	## dist.matrix <- dist( waypts[,c(2,3)], upper=TRUE )
	## use the fields version
	## statute miles, earth radius, etc. as inputs
	dist.matrix <-  rdist.earth( waypts[,2:3], R=3949.0 )

	## prepare the data for the solve_tsp function
	rtsp <- TSP( dist.matrix )

	## solve it, and
	soln <- solve_TSP( rtsp )

	## coerce into a vector of ids
	tour <- as.vector( soln )

	## return a text vector of tour
	return( paste( as.character( tour ), collapse="," ) )

$$
language 'plr' strict;



CREATE VIEW RPT_STANDS AS
SELECT 
       *,
       ST_AsText(boundary) as wktgeom, -- this is the data 'type' that is needed by sqli2map()
       st_xmin( boundary) as minx, -- looks like the function also needs the bbox too.
       st_ymin( boundary) as miny,
       st_xmax( boundary) as maxx,
       st_ymax( boundary) as maxy
FROM
	stands
ORDER BY
      id;



--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- this is the final function that will get used to generate the tour
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

drop table if exists events cascade;
create table events
(
  seqid int not null primary key, -- visit sequence #
  plotid int, -- original plot id
  bearing real, -- bearing to next waypoint
  distance real,  -- distance to next waypoint
  velocity real, 
  traveltime real,
  loitertime real,
  totaltraveldist real,
  totaltraveltime real
);

SELECT AddGeometryColumn('','events','location','4326','POINT',2);
CREATE INDEX "events_location_gist" ON "events" using gist ("location" gist_geometry_ops);


-- this is the version of the function that will be used for the demonstration.
drop function if exists solve_tsp( int );
create or replace function solve_tsp ( int ) returns setof events as
$$
  ## load your libraries, prep data, and solve
  if(!require(TSP, quietly=TRUE)) install.packages("TSP")
  if(!require(fields, quietly=TRUE)) install.packages("fields")
  sql.str <- "select id, st_x(location) as x, st_y(location) as y, location from stands;"
  waypts <- pg.spi.exec( sql.str )         	
  ## statute miles, earth radius, etc. as inputs
  ## assume the radius of the earth is 3959.0 nm
  dist.matrix <-  rdist.earth( waypts[,2:3], R=3949.0 )
  rtsp <- TSP( dist.matrix )
  soln <- solve_TSP( rtsp )
  tour <- as.vector( soln )
  pg.thrownotice( paste( "tour.dist=", attributes( soln )$tour_length) )

  tour.df <- NULL
  for( i in tour ) {
    plot.df <- data.frame( seqid=i, plotid=waypts[tour[i],]$id )	
    tour.df <- rbind( tour.df, plot.df )	  
  }  

  ## velocity (in miles/hour)
  velocity <- 500.0
  
  ################################################################################
  ## build the vector of distances to next point
  starts <- tour[1:(length(tour))-1]
  stops <- tour[2:(length(tour))]
  dist.vect <- diag( as.matrix( dist.matrix )[starts,stops] )
  last.leg <- as.matrix( dist.matrix )[tour[length(tour)],tour[1]]
  dist.vect <- c(dist.vect, last.leg )

  ################################################################################
  ## build a vector of the bearings to the next point
  delta.x <- diff( waypts[tour,]$x )
  delta.y <- diff( waypts[tour,]$y )
  bearings <- atan( delta.x/delta.y ) * 180 / pi
  bearings <- c(bearings,0)
  for( i in 1:(length(tour)-1) ) {
    if( delta.x[i] > 0.0 && delta.y[i] > 0.0 ) bearings[i] <- bearings[i]
    if( delta.x[i] > 0.0 && delta.y[i] < 0.0 ) bearings[i] <- 180.0 + bearings[i]
    if( delta.x[i] < 0.0 && delta.y[i] > 0.0 ) bearings[i] <- 360.0 + bearings[i]
    if( delta.x[i] < 0.0 && delta.y[i] < 0.0 ) bearings[i] <- 180 + bearings[i]
  }

  ################################################################################
  ## generate your final data.frame
  route <- data.frame( seq=1:length(tour),
                     ptid=tour,                  
                     bearing=bearings,
                     dist.vect=dist.vect,
                     velocity=velocity,
                     travel.time=dist.vect/velocity,
                     loiter.time=0.5)
  route$total.travel.dist <- cumsum( route$dist.vect )
  route$total.travel.time <- cumsum( route$travel.time+route$loiter.time )
  route$location <- waypts[tour,]$location

  ## also, generate a temporary pdf map
  if(!require(maps, quietly=TRUE)) install.packages("maps")
  ## generate a plot for the prez
  pdf( "tour-with-map-from-plr.pdf" )
  map('world2', xlim = c(20, 120), ylim=c(20,80) )
  map.axes()
  grid()
  arrows(
      waypts[tour[1:(length(tour)-1)],]$x,
      waypts[tour[1:(length(tour)-1)],]$y,
      waypts[tour[2:(length(tour))],]$x,
      waypts[tour[2:(length(tour))],]$y,
      angle=10, 
      lwd=1,
      length=.15,
      col="red")
  points( waypts$x, waypts$y, pch=3, cex=2 )
  points( waypts$x, waypts$y, pch=20, cex=0.8 )
  text(  waypts$x+2, waypts$y+2, as.character( waypts$id  ), cex=0.8 )
  title( "TSP soln using PL/R" )
  dev.off()

  ## return the properly formatted data.frame (\d events)
  return( route )
$$
language 'plr' strict;


--------------------------------------------------------------------------------
-- finally, using ogr2ogr, export the view as a google earth file
-- you can now use the view from within ogr2ogr to generate a google earth file.
--------------------------------------------------------------------------------

-- /usr/local/bin/ogr2ogr -f KML tsp.kml PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from solve_tsp(0)" -nlt POINT -nln tour

-- then, finally
-- $ open tsp.kml


--------------------------------------------------------------------------------
-- create a view for exporting the tour to your gps unit
--------------------------------------------------------------------------------

-- drop view if exists gpx_soln;
create or replace view gpx_soln as select 
       cast( 'Waypts' as text ) as type, 
       'Waypt # ' || seqid as name,
       astext(st_transform(location,4326)), 
       E'SOLPOS,SOLANG,LOITM,???' as desc
from 
     solve_tsp(1)
order by
      seqid;


-- /usr/local/bin/ogr2ogr -f GPX tour.gpx PG:"host=localhost user=postgres dbname=pgissc" -sql "select * from gpx_soln" -nlt POINT -nln tour

-- then, finally... open a windows box and move the gpx file into the magellan gps software, and ... 
-- $ open tsp.kml



